package com.example.ecommerce.model;

public enum OrderStatus {
    PENDING, SHIPPED, DELIVERED, CANCELLED
}
